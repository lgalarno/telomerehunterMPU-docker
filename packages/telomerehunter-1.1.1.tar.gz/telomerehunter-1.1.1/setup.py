#!/usr/bin/env python

from distutils.core import setup

setup(name='telomerehunter',
      version='1.1.1',
      description='TelomereHunter extracts, sorts and analyses telomeric reads from WGS Data.',
      long_description='file: README.md',
      long_description_content_type='text/markdown',
      author='Lars Feuerbach <l.feuerbach@dkfz-heidelberg.de>, Philip Ginsbach, Lina Sieverling <l.sieverling@dkfz-heidelberg.de>, Luc Galarneau',
      author_email='l.sieverling@dkfz-heidelberg.de',
      url='',
      keywords=["telomere", "content", "read", "NGS", "WGS", "tumor", "control"],
      packages=['telomerehunter'],
      package_dir={'telomerehunter': 'src/telomerehunter'},
      package_data={'': ['*.r', '*.R', '*.TXT', '*.txt']},
      include_package_data=True,
      scripts=['scripts/telomerehunter'],
      # entry_points={
      #     "console_scripts": [
      #         "telomerehunter = telomerehunter.__name__:telomerehunter",
      #     ]
      # },
      classifiers=[
          "Programming Language:: Python:: 2",
          "Programming Language:: Python:: 2.7",
          "License:: OSI Approved:: GNU General Public License(GPL)",
          "Operating System:: OS Independent",
          "Intended Audience:: Developers",
          "Intended Audience:: Science / Research",
          "Topic:: Scientific / Engineering:: Medical Science Apps."
      ],
      install_requires=(
        "PyPDF2==1.26.0",
        "pysam==0.9.0",
       " numpy==1.16.6"
      ),
      )

# from setuptools import setup
#
# setup()

